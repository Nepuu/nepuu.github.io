<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <form action="function/login_action.php" method="post">
        <table>
            <tr>
                <td>Nama</td>
                <td> : </td>
                <td><input type="text" name="nama" autocomplete="off" required></td>
            </tr>
            <tr>
                <td>Password</td>
                <td> : </td>
                <td><input type="password" name="pass" autocomplete="off" required></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><input type="submit" value="Login"></td>
            </tr>
        </table>
    </form>
    <hr>
    Isi Nama & Password dengan <font color=blue>admin</font> untuk Login sebagai Admin.<br>
    Isi Nama & Password dengan <font color=blue>user</font> untuk Login sebagai Pengguna.
</body>
</html>