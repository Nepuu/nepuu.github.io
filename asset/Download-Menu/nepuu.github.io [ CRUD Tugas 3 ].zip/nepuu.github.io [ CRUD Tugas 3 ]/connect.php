<?php
$connect = mysqli_connect ("localhost", "root", "", "restoran");
?>