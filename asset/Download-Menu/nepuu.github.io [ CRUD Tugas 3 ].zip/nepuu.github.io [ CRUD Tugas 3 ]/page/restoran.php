<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restoran Kecil</title>
</head>
<body>
    <h1>Restoran Kecil</h1>
    <table border=1 cellspacing=0 cellpadding=7.5px>
        <tr>
            <th>No</th>
            <th>Nama Makanan</th>
            <th>Harga</th>
            <th>Jumlah Porsi</th>
            <th>Total</th>
        </tr>
        <?php
        function rp ($angka) {
            $hasil_rp = number_format ($angka,0,',','.');
            return $hasil_rp;
        }
        include '../connect.php';
        $number = 1;
        $data = mysqli_query ($connect, "select * from makanan");
        while ($d = mysqli_fetch_array ($data)) {
        ?>
        <tr align=center>
            <td><?php echo $number ++; ?></td>
            <td><?php echo $d ['nama']; ?></td>
            <td align=left><?php echo 'Rp. ' . rp ($d ['harga']); ?></td>
            <td><?php echo $d ['porsi']; ?></td>
            <td align=left><?php echo 'Rp. ' . rp ($d ['total']); ?></td>
        </tr>
        <?php
        }
        ?>
    </table>
</body>
</html>