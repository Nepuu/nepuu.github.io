<?php
include '../connect.php';

$id = $_GET ['id'];

mysqli_query ($connect, "delete from makanan where no='$id'");

header ("Location: ../page/administrator.php");
?>