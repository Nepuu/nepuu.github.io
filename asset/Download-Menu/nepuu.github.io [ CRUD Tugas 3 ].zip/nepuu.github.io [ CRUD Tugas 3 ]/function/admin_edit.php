<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Menu</title>
</head>
<body>
    <a href="../page/administrator.php">Batal</a>
    <h1>Edit Menu</h1>
    <form action="admin_edit_action.php" method="post">
        <table>
        <?php
        include '../connect.php';
        $id = $_GET ['id'];
        $data = mysqli_query ($connect, "select * from makanan where no='$id'");
        while ($d = mysqli_fetch_array ($data)) {
        ?>
            <tr>
                <td>Nama Makanan</td>
                <td> : </td>
                <td>
                    <input type="hidden" name="id" value="<?php echo $d ['no']; ?>">
                    <input type="text" name="nama" value="<?php echo $d ['nama'];?>" autocomplete="off" required>
                </td>
            </tr>
            <tr>
                <td>Harga</td>
                <td> : </td>
                <td><input type="number" name="harga" min=1 value="<?php echo $d ['harga'];?>" autocomplete="off" required></td>
            </tr>
            <tr>
                <td>Jumlah Porsi</td>
                <td> : </td>
                <td><input type="number" name="porsi" min=1 value="<?php echo $d ['porsi'];?>" autocomplete="off" required></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><input type="submit" value="Simpan Perubahan"></td>
            </tr>
            <?php
        }
        ?>
        </table>
    </form>
</body>
</html>