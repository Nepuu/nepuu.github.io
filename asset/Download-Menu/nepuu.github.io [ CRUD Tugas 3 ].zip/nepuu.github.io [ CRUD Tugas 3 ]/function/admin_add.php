<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Menu</title>
</head>
<body>
    <a href="../page/administrator.php">Batal</a>
    <h1>Tambah Menu</h1>
    <form action="admin_add_action.php" method="post">
        <table>
            <tr>
                <td>Nama Makanan</td>
                <td> : </td>
                <td><input type="text" name="nama" autocomplete="off" required></td>
            </tr>
            <tr>
                <td>Harga</td>
                <td> : </td>
                <td><input type="number" name="harga" min=1 autocomplete="off" required></td>
            </tr>
            <tr>
                <td>Jumlah Porsi</td>
                <td> : </td>
                <td><input type="number" name="porsi" min=1 autocomplete="off" required></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><input type="submit" value="Tambah Menu"></td>
            </tr>
        </table>
    </form>
</body>
</html>