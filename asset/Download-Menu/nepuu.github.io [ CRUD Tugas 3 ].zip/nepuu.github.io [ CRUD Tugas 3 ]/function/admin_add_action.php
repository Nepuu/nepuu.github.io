<?php
include '../connect.php';

$nama = $_POST ['nama'];
$harga = $_POST ['harga'];
$porsi = $_POST ['porsi'];

$total = $harga * $porsi;

mysqli_query ($connect, "insert into makanan values ('','$nama','$harga', '$porsi', '$total')");

header ("Location: ../page/administrator.php");
?>