<?php
$nama = $_POST ['nama'];
$pass = $_POST ['pass'];

if ($nama == 'admin' && $pass == 'admin') {
    header ("Location: ../page/administrator.php");
} elseif ($nama == 'user' && $pass == 'user') {
    header ("Location: ../page/restoran.php");
} else {
    echo "<script>alert ('Login Gagal. Harap masukkan data dengan benar.'); document.location.href='../index.php';</script>";
}
?>