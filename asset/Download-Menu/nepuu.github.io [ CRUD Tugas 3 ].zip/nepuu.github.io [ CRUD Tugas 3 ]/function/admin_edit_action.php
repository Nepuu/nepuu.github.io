<?php
include '../connect.php';

$id = $_POST ['id'];
$nama = $_POST ['nama'];
$harga = $_POST ['harga'];
$porsi = $_POST ['porsi'];

$total = $harga * $porsi;

mysqli_query ($connect, "update makanan set nama='$nama', harga='$harga', porsi='$porsi', total='$total' where no='$id'");

header ("Location: ../page/administrator.php");
?>