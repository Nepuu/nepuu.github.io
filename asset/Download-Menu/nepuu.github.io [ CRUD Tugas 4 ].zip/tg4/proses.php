<?php
$nama = $_POST ['nama'];
$tindakan = $_POST ['tindakan'];

class Data {
    public $n;
    public $t;

    function in_nama ($n) {
        $this -> n = $n;
    }
    
    function in_tindakan ($t) {
        $this -> t = $t;
    }

    function out_nama () {
        return $this -> n;
    }

    function out_tindakan () {
        return $this -> t;
    }
}

$n_data = new Data ();
$t_data = new Data ();

$n_data -> in_nama ($nama);
$t_data -> in_tindakan ($tindakan);

echo "<title>Tugas 4</title>";
echo "Nama saya adalah <b>" . $n_data -> out_nama () . "</b>, saya sekarang sedang <b>" . $t_data -> out_tindakan () . "</b>."; 
?>