<?php
$k=$_POST['k'];
$a=$_POST['A'];
$t1=$_POST['T1'];
$t2=$_POST['T2'];
$l=$_POST['L'];
$dt=$t2-$t1;

switch($k){
    case "alumunium":
        $H=204*$a*($dt/$l);
        echo "$H";
        break;
    case "tembaga":
        $H=386*$a*($dt/$l);
        echo "$H";
        break;
    case "perak":
        $H=407*$a*($dt/$l);
        echo "$H";
        break;
    case "besi":
        $H=73 *$a*($dt/$l);
        echo "$H";
        break;
    case "seng":
        $H=166*$a*($dt/$l);
        echo "$H";
        break;
    case "timah":
        $H=64*$a*($dt/$l);
        echo "$H";
        break;
}
?>